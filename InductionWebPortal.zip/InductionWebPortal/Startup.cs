﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(InductionWebPortal.Startup))]
namespace InductionWebPortal
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
